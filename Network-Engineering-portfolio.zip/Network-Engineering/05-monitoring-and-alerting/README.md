# 05 · Monitoring & Alerting

## 🎯 Project Goal

Build a full-stack network monitoring pipeline that:
1. Collects metrics from network devices and servers via **SNMP** and **gNMI streaming telemetry**
2. Stores time-series data in **InfluxDB**
3. Visualises it in **Grafana** dashboards
4. Alerts on thresholds via **Slack**

This replaces "log into a device and check" with always-on, historical, visualised monitoring.

---

## 🏗️ Architecture

```
Network Devices          Telegraf             InfluxDB          Grafana
(Cisco / Arista)   ──→  (Collector)    ──→  (Time-series  ──→  (Dashboards
                         SNMP polls          database)          & Alerts)
                         gNMI subscribe
                         Ping probes
```

---

## Step-by-Step Explanation

### Step 1 — Why Two Collection Methods (SNMP vs gNMI)?

**SNMP (Simple Network Management Protocol):**
- Works on virtually every network device made in the last 30 years
- Pull-based: Telegraf polls the device every 30–60 seconds
- Good for: interface counters, CPU, memory, BGP prefix count
- Limitation: 30-second resolution misses sub-minute events (microbursts)

**gNMI (gRPC Network Management Interface):**
- Push-based: the device streams metrics to Telegraf in real time
- Sub-second resolution possible (100ms intervals)
- Supported on: Cisco IOS-XR/NX-OS, Arista EOS, Juniper (modern platforms)
- Good for: queue drops, optical power levels, interface errors in real time

**Use both:** SNMP for broad compatibility, gNMI for high-resolution data on modern gear.

---

### Step 2 — Telegraf Configuration

Telegraf is the collection agent. It is configured with **inputs** (data sources) and **outputs** (where to send data).

See: [`telegraf/telegraf.conf`](telegraf/telegraf.conf)

---

### Step 3 — InfluxDB Setup

InfluxDB stores time-series data. Unlike a SQL database, every row has an automatic timestamp, making it ideal for metrics.

**Key concepts:**
- **Bucket** = database (e.g., `network_metrics`)
- **Measurement** = table (e.g., `interface`, `bgp`, `cpu`)
- **Tag** = indexed string field used for filtering (e.g., `host=core-sw-1`, `interface=Gi1/0/1`)
- **Field** = numeric value (e.g., `bytes_in=1234567`)

Setup commands:
```bash
# Start InfluxDB
docker run -d -p 8086:8086 \
  -e INFLUXDB_DB=network_metrics \
  -e INFLUXDB_ADMIN_USER=admin \
  -e INFLUXDB_ADMIN_PASSWORD=Str0ngP@ss! \
  influxdb:2.7

# Create bucket
influx bucket create --name network_metrics --retention 90d
```

---

### Step 4 — Grafana Dashboard

Grafana connects to InfluxDB and visualises the data. Key dashboards:

**Interface Utilisation Dashboard:**
- Line chart of bytes in/out per interface
- Alert rule: if bytes_in > 80% of interface speed for >5 minutes → Slack alert

**BGP Summary Dashboard:**
- BGP session state per device (green=Established, red=Down)
- Prefix count over time (sudden drop = route withdrawal)

**Data Center Environmental Dashboard:**
- Temperature per rack sensor
- Fan speed per server
- PDU power draw per rack

Import dashboard JSON from: [`dashboards/`](dashboards/)

---

### Step 5 — Alerting

Alerts in Grafana use **Alert Rules** that query InfluxDB on a schedule.

Example alert: "Interface utilisation >80% for 5 minutes"
```
Query: SELECT mean("bytes_in") FROM "interface" 
       WHERE time > now()-5m 
       GROUP BY "host","interface"
Condition: IS ABOVE (interface_speed * 0.80)
Action: Send to Slack channel #network-alerts
```

See alert config: [`dashboards/alert_rules.json`](dashboards/alert_rules.json)

---

## Quick Start (Docker Compose)

The entire stack runs with a single command:

```bash
cd 05-monitoring-and-alerting
docker-compose up -d

# Services:
# Telegraf  → collecting metrics
# InfluxDB  → http://localhost:8086
# Grafana   → http://localhost:3000 (admin/admin)
```

See: [`docker-compose.yml`](docker-compose.yml)
