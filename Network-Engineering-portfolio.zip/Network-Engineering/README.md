# 🌐 Network Engineering & Data Center Portfolio

> **Enterprise Network Design · Data Center Infrastructure · Network Automation · Troubleshooting**

[![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)](https://python.org)
[![Ansible](https://img.shields.io/badge/Ansible-2.14+-red?logo=ansible)](https://ansible.com)
[![Cisco](https://img.shields.io/badge/Cisco-IOS%20%7C%20NX--OS-blue?logo=cisco)](https://cisco.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 👋 About This Repository

This repository showcases hands-on projects demonstrating skills in:

- **Enterprise Network Engineering** — design, configuration, and validation of multi-site campus and WAN networks
- **Data Center Technician Skills** — server rack installation, structured cabling, power & cooling planning
- **Network Automation** — Python (Netmiko/NAPALM/Nornir), Ansible playbooks, GitOps workflows
- **Troubleshooting** — systematic runbooks for L1/L2/L3 and data center fault isolation
- **Monitoring & Alerting** — SNMP polling, streaming telemetry (gNMI), Grafana dashboards

Each project folder is self-contained with configs, scripts, diagrams, and a full step-by-step explanation so any engineer can understand, replicate, or extend the work.

---

## 📁 Project Structure

```
Network-Engineering/
├── 01-enterprise-network-design/       # Campus + WAN topology with configs
├── 02-datacenter-rack-installation/    # Rack layout, cabling, power planning
├── 03-network-automation/              # Python & Ansible automation scripts
├── 04-troubleshooting-runbooks/        # L1/L2/L3 & DC fault isolation guides
└── 05-monitoring-and-alerting/         # SNMP, streaming telemetry, dashboards
```

---

## 🚀 Projects at a Glance

| # | Project | Skills Demonstrated | Tech Stack |
|---|---------|--------------------|-----------:|
| 01 | [Enterprise Network Design](./01-enterprise-network-design/) | VLANs, OSPF, BGP, HSRP, ACLs | Cisco IOS / NX-OS |
| 02 | [Data Center Rack Installation](./02-datacenter-rack-installation/) | Rack layout, structured cabling, PDU planning | Visio / Excel |
| 03 | [Network Automation](./03-network-automation/) | Config push, compliance, telemetry | Python, Ansible, Nornir |
| 04 | [Troubleshooting Runbooks](./04-troubleshooting-runbooks/) | Systematic fault isolation | CLI, Wireshark |
| 05 | [Monitoring & Alerting](./05-monitoring-and-alerting/) | SNMP, gNMI, dashboards | Telegraf, InfluxDB, Grafana |

---

## 🛠️ Tools & Technologies

**Networking:** Cisco IOS, IOS-XE, NX-OS, Arista EOS, Juniper JunOS  
**Protocols:** OSPF, BGP, EIGRP, STP, RSTP, LACP, VRRP/HSRP, 802.1Q  
**Automation:** Python 3, Ansible, Nornir, Netmiko, NAPALM, Jinja2  
**Data Center:** Structured cabling (TIA-942), PDU sizing, rack unit planning, hot/cold aisle  
**Monitoring:** SNMP v2c/v3, gNMI, Telegraf, InfluxDB, Grafana  
**CI/CD:** GitHub Actions, ansible-lint, yamllint  

---

## 📬 Contact

Open to **Network Engineer** and **Data Center Technician** opportunities.  
Feel free to raise an Issue or reach out via GitHub Discussions.
