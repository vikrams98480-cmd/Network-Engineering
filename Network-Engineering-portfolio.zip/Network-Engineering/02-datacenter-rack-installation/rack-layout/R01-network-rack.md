# Rack Elevation — R01 (Network Rack)

**Rack spec:** 42U, 600mm × 1200mm, open frame  
**PDU-A:** APC AP8853 30A/208V (right side)  
**PDU-B:** APC AP8853 30A/208V (left side)  
**Total power draw:** 4.0 kW  

---

```
┌─────────────────────────────────────────────────┐
│ U  │ Device                        │ Type        │
├────┼───────────────────────────────┼─────────────┤
│ 1  │ 1U Blank                      │ Filler      │
│ 2  │ Patch Panel A (24-port Cat6A) │ PP-R01-A    │
│ 3  │ 1U Cable Manager (horizontal) │ MGMT        │
│ 4  │ Patch Panel B (24-port Cat6A) │ PP-R01-B    │
│ 5  │ 1U Cable Manager (horizontal) │ MGMT        │
│ 6  │ Patch Panel C (24-port Cat6A) │ PP-R01-C    │
│ 7  │ 1U Blank                      │ Filler      │
│ 8  │ Cisco Catalyst 9500 (Core-1)  │ 2U Switch   │
│ 9  │ (Core-1 continued)            │             │
│ 10 │ 1U Cable Manager              │ MGMT        │
│ 11 │ Cisco Catalyst 9500 (Core-2)  │ 2U Switch   │
│ 12 │ (Core-2 continued)            │             │
│ 13 │ 1U Blank                      │ Filler      │
│ 14 │ Cisco Firepower 2140 (FW-1)   │ 1U FW       │
│ 15 │ 1U Blank                      │ Filler      │
│ 16 │ Cisco Firepower 2140 (FW-2)   │ 1U FW       │
│ 17 │ 1U Blank                      │ Filler      │
│18-20│ 3x 1U Blank                  │ Filler      │
│21-30│ 10x 1U Blank (reserved)      │ Future      │
│ 31 │ 1U Blank                      │ Filler      │
│32-37│ 6x 1U Blank                  │ Filler      │
│ 38 │ 1U Cable Manager              │ MGMT        │
│ 39 │ APC Smart-UPS SRT 3000VA      │ 2U UPS      │
│ 40 │ (UPS continued)               │             │
│ 41 │ PDU-A (vertical, side mount)  │ Power       │
│ 42 │ PDU-B (vertical, side mount)  │ Power       │
└─────────────────────────────────────────────────┘
```

---

## Device Details

### Core-1 (Cisco Catalyst 9500-48Y4C)
- **Position:** U8–U9
- **Management IP:** 10.10.40.201
- **Serial:** CAT2345678A
- **Interfaces used:** 1-24 (downlinks to distribution), 25-28 (uplinks 100G)
- **Power draw:** 850W × 2 PSU = dual-homed PDU-A/PDU-B

### Core-2 (Cisco Catalyst 9500-48Y4C)
- **Position:** U11–U12
- **Management IP:** 10.10.40.202
- **Serial:** CAT2345678B

### FW-1 / FW-2 (Cisco Firepower 2140)
- **Position:** U14 / U16
- **Management IP:** 10.10.40.210 / 10.10.40.211
- **Role:** Active/Standby HA pair

---

## Cable Schedule (R01 internal)

| Cable ID     | From                  | To                     | Type   | Length |
|-------------|----------------------|------------------------|--------|--------|
| R01-C001    | Core-1 Gi1/0/1       | PP-R01-A Port 01       | Cat6A  | 0.5m   |
| R01-C002    | Core-1 Gi1/0/2       | PP-R01-A Port 02       | Cat6A  | 0.5m   |
| R01-F001    | Core-1 100G Uplink-1 | Patch Panel Fibre-01   | OM4 LC | 1.0m   |
| R01-F002    | Core-2 100G Uplink-1 | Patch Panel Fibre-02   | OM4 LC | 1.0m   |

> Full cabling schedule is in [`../cable-management/cabling-schedule.md`](../cable-management/cabling-schedule.md)
