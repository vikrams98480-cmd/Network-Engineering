# 02 · Data Center Rack Installation

## 🎯 Project Goal

Plan and document the physical installation of a **12-rack enterprise data center pod** including server rack layout, structured cabling (TIA-942), power distribution (PDU sizing), cable management, and a hot/cold aisle containment design.

This project proves you can:
- Read and produce rack elevation diagrams
- Plan structured cabling with proper labelling
- Size PDUs and calculate power density per rack
- Apply data center best practices (hot/cold aisle, cable management, airflow)
- Document everything an installation team needs to execute the build

---

## 🏗️ Pod Layout

```
                    COLD AISLE (front of racks)
   ┌────────────────────────────────────────────────────────┐
   │  R01   R02   R03   R04   R05   R06  │  R07   R08  ...  │
   │  [↓]   [↓]   [↓]   [↓]   [↓]   [↓] │  [↓]   [↓]  ...  │
   └────────────────────────────────────────────────────────┘
                    HOT AISLE (rear of racks)
```

**Rack assignment:**

| Rack | Type          | Contents                              | Power (kW) |
|------|---------------|---------------------------------------|-----------|
| R01  | Network       | Core switches, patch panels           | 4.0       |
| R02  | Network       | Distribution switches, firewall       | 3.5       |
| R03  | Compute       | 4x Dell PowerEdge R750 servers        | 8.0       |
| R04  | Compute       | 4x Dell PowerEdge R750 servers        | 8.0       |
| R05  | Compute       | 4x HPE ProLiant DL380 servers         | 7.5       |
| R06  | Storage       | NetApp AFF A250 + disk shelves        | 6.0       |
| R07  | Storage       | Backup appliance + tape library       | 4.0       |
| R08  | Management    | KVM, OOB management, console servers  | 2.0       |
| R09  | Spare / Future| Empty (reserved)                      | 0.0       |

---

## 📋 Step-by-Step Explanation

### Step 1 — Site Survey and Pre-Installation Checklist

**Why:** Before any equipment arrives, you must confirm the physical environment meets requirements. Arriving on-site without this means delays and potential damage to equipment.

Key checks:
- **Floor load capacity** ≥ 1,500 kg/m² (data center racks can weigh 500–700 kg each when full)
- **Raised floor or cable tray** routes confirmed for power and data cables
- **Ambient temperature** 18–27°C (ASHRAE A1 class) — check HVAC is running before powering gear
- **Humidity** 40–60% RH (too dry = static discharge; too wet = condensation)
- **Power circuits** — verify each rack position has the correct breaker amperage (see Step 3)
- **Rack anchoring points** confirmed (seismic anchors if required by local code)

See: [`docs/site-survey-checklist.md`](docs/site-survey-checklist.md)

---

### Step 2 — Rack Elevation Planning

**Why:** A rack elevation diagram shows the exact unit (U) position of every device before you unbox anything. This prevents situations like a 4U UPS sitting below a 2U server that should have gone in first (you would have to unmount everything to slide it in).

**Rules of thumb:**
- Heaviest gear (UPS, batteries) at the **bottom** (low centre of gravity)
- Patch panels at the **top** (cabling fans out from there)
- 1U blanking panels fill every empty U — this is critical for airflow (prevents hot air recirculation)
- Leave 1U gap above and below high-heat equipment (GPUs, dense storage)
- Cable managers (1U horizontal) between patch panels and active gear

See rack elevations: [`rack-layout/R01-network-rack.md`](rack-layout/R01-network-rack.md)

---

### Step 3 — Power Distribution Planning

**Why:** Under-sized PDUs trip breakers under full load; over-sized ones waste money. You must calculate per-rack power draw at full capacity plus a 20% headroom.

**Formula:**
```
Total Watts = Sum of all device TDP (Thermal Design Power) ratings
Amps at 120V = Watts ÷ 120
Amps at 208V = Watts ÷ 208

Rule: Never load a circuit above 80% of its rated amperage.
So a 30A/208V circuit can safely carry: 30 × 0.8 × 208 = 4,992W ≈ 5kW
```

**R03 example (compute rack):**
```
4x Dell R750 (750W TDP each) = 3,000W
2x 1G switches (150W each)   =   300W
Patch panels/misc             =   100W
Total:                          3,400W
+ 20% headroom:                 4,080W
→ Requires 30A/208V PDU (dual PDU for redundancy)
```

Each rack gets **two PDUs** (A-feed and B-feed from different UPS units) for N+1 redundancy. Servers with dual PSUs plug one into PDU-A and one into PDU-B.

See: [`docs/power-budget.md`](docs/power-budget.md)

---

### Step 4 — Structured Cabling

**Why:** Properly labelled and routed cables are the difference between a 10-minute troubleshoot and a 3-hour nightmare. TIA-942 defines the standard for data center cabling.

**Cable types used:**
- **Cat6A UTP** — copper, 10GbE server connections, max 100m
- **OM4 Multi-mode fibre** — switch-to-switch uplinks (up to 400m at 10G)
- **OS2 Single-mode fibre** — inter-building or long-distance runs

**Labelling convention:**
```
Format: [SOURCE_RACK]-[SOURCE_PORT]_TO_[DEST_RACK]-[DEST_PORT]
Example: R01-P01-PORT01_TO_R03-SRV01-NIC1

Every cable is labelled at BOTH ends.
```

**Cable routing rules:**
- Data cables (blue/yellow) run on the **left** side of the rack
- Power cables (black) run on the **right** side
- Fibres (orange/aqua) get their own dedicated fibre tray (strain-sensitive)
- All cables are dressed with Velcro ties (not zip ties — you will remove cables)
- No cable radius smaller than 4× the cable diameter

See: [`cable-management/cabling-schedule.md`](cable-management/cabling-schedule.md)

---

### Step 5 — Server Rack Installation Procedure

**Why:** Following a standard installation sequence prevents dropped components, ESD damage, and missed steps that cause failures during first power-on.

**Procedure for each server:**
1. Confirm rail kit matches rack post hole pattern (square, round, or threaded)
2. Torque rack screws to spec (typically 0.6–0.8 N·m — hand-tight + quarter turn)
3. Attach ESD wrist strap before touching any component
4. Slide server into rails — listen for the click of the latch
5. Connect all cable connections BEFORE power:
   - Management (iDRAC/iLO) first — you need this for firmware update
   - Network NICs
   - Storage HBAs
   - Power cords (A-feed, then B-feed)
6. Power on and confirm POST via console / iDRAC
7. Verify BMC (iDRAC/iLO) is accessible over management network

---

### Step 6 — Hot/Cold Aisle Containment

**Why:** Without containment, hot exhaust air mixes with cold intake air. This forces the HVAC to work harder and can create hot spots that throttle or damage servers. Containment improves PUE (Power Usage Effectiveness) by 15–30%.

**Implementation:**
- All racks face the same direction (front = cold aisle, rear = hot aisle)
- Blanking panels fill every empty rack U — a single open 1U gap can recirculate 15% of hot air
- Cold aisle doors at both ends (physical or air curtain)
- Hot aisle ceiling containment with return plenum to CRAC/CRAH units
- Perforated floor tiles (if raised floor) placed only in front of racks

---

### Step 7 — Cable Testing and Sign-Off

**Why:** A cable that looks fine can have a broken wire inside. Every cable must be tested before the rack goes live.

**Testing matrix:**
- Cat6A: Fluke DSX-600 or similar — test for **wire map, length, insertion loss, NEXT, PS-ACRF** (TIA-568 Cat6A limits)
- Fibre: OTDR trace + insertion loss test (≤0.5dB per mated pair for OM4)
- Power: Verify correct voltage at each PDU outlet before connecting equipment
- All test results are saved as PDF and committed to this repo

See: [`docs/cable-test-results/`](docs/cable-test-results/)

---

### Step 8 — Handover Documentation

**Why:** The installation team hands over to the operations team. Without documentation, ops has no idea what is where, how it is cabled, or how to access it.

Handover pack includes:
- As-built rack elevation diagrams (matches physical state, not just planned)
- Cabling schedule (source → destination, cable ID, length, test result pass/fail)
- IP address list (management IPs for every server BMC, switch, PDU)
- Power budget actuals (measured vs calculated)
- Thermal scan photos (IR camera of rear of racks under load)
- Sign-off sheet with customer and installer signatures
