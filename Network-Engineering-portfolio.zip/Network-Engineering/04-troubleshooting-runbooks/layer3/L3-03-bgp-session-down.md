# Runbook L3-03 — BGP Session Down

**Symptom:** Internet connectivity is lost. `show bgp summary` shows the ISP neighbor in a non-`Established` state (e.g., `Idle`, `Active`, `Connect`, `OpenSent`).  
**Severity:** P1 — Business impacting  
**Estimated resolution time:** 15–60 minutes depending on root cause  
**Escalation:** If not resolved in 60 minutes → call ISP NOC

---

## Understanding BGP States

Before troubleshooting, understand what each state means:

| State | Meaning | Your action |
|-------|---------|-------------|
| `Idle` | BGP not trying to connect. Session was reset or never started. | Check config, check `no shutdown` on neighbor |
| `Active` | BGP is trying to connect but failing TCP handshake | Check reachability, ACLs, TCP port 179 |
| `Connect` | TCP SYN sent, waiting for SYN-ACK | Check ISP, check firewall |
| `OpenSent` | TCP connected, BGP OPEN message sent, waiting for ISP reply | Check AS numbers and router-id in config |
| `OpenConfirm` | Exchanging OPEN messages | Check BGP capabilities, MD5 password |
| `Established` | ✅ Working normally | N/A |

---

## Step 1 — Confirm the Problem

```bash
show bgp summary
```

**What to look for:**
```
Neighbor        V  AS  MsgRcvd MsgSent TblVer InQ OutQ Up/Down  State/PfxRcd
203.0.113.1     4  65000  0       0       0    0    0    never    Active      ← PROBLEM
```

If `Up/Down` shows `never` and `State/PfxRcd` is a word (not a number), the session is down.

---

## Step 2 — Check Physical Connectivity to ISP

**Why first:** No point debugging BGP if the wire is unplugged.

```bash
show interface GigabitEthernet0/0/0
```

✅ Must show `GigabitEthernet0/0/0 is up, line protocol is up`  
❌ If `down/down` → **go to Runbook L1-01** (physical link)  
❌ If `up/down` → line protocol issue — check encapsulation, keepalives  

```bash
ping 203.0.113.1      ← Ping ISP's end of the /30 link
```

✅ Ping succeeds → IP reachability is fine, issue is BGP-specific → go to Step 3  
❌ Ping fails → IP reachability problem → go to Step 2a  

### Step 2a — IP reachability fails

```bash
show ip interface GigabitEthernet0/0/0
```

Check:
- IP address matches the ISP-assigned address
- No ACL blocking ICMP (`ip access-group` on the interface)

```bash
show ip interface GigabitEthernet0/0/0 | include access list
```

If an ACL is applied, verify it permits traffic to/from 203.0.113.1.

---

## Step 3 — Check BGP Configuration

**Common config mistakes that kill BGP:**

```bash
show run | section router bgp
```

Check each of these carefully:

### 3a — Correct remote AS number
```
neighbor 203.0.113.1 remote-as 65000   ← Must match ISP's actual AS
```
❌ Wrong AS → `OpenSent` or `Idle` state. Verify with ISP NOC.

### 3b — Correct neighbor IP
```
neighbor 203.0.113.1   ← Must be the ISP's IP on the /30, not yours
```
❌ Using your own IP as the neighbor = session never connects

### 3c — BGP router-id is unique
```bash
show bgp summary | include router ID
```
If two routers in the same AS have the same router-id, unexpected resets occur.
BGP router-id defaults to the highest loopback IP. Override explicitly:
```
router bgp 65001
 bgp router-id 10.0.0.1
```

### 3d — MD5 password mismatch
If BGP MD5 authentication is configured:
```bash
show bgp neighbors 203.0.113.1 | include password
```
A password mismatch shows `MD5 authentication is configured` on your side but
the session stays in `Active`. Verify the password string with the ISP exactly —
one wrong character kills authentication.

---

## Step 4 — Check TCP Port 179

BGP uses TCP port 179. If a firewall or ACL is blocking it, the session can't form.

```bash
# From the router, try to reach port 179 on the ISP router
telnet 203.0.113.1 179
```

✅ Connection opens (shows escape character message) → TCP is fine, issue is BGP  
❌ `Connection refused` or `Connection timed out` → port 179 is blocked  

Check for ACLs on the WAN interface:
```bash
show ip access-lists WAN_INBOUND
show run interface GigabitEthernet0/0/0 | include access-group
```

Ensure TCP port 179 is permitted:
```
permit tcp host 203.0.113.1 any eq 179
permit tcp any eq 179 host 203.0.113.1
```

---

## Step 5 — Check BGP Notification Messages

BGP sends a NOTIFICATION message with an error code when it resets. This is the most
specific diagnostic information available.

```bash
show bgp neighbors 203.0.113.1 | include notification|error|reset
```

Common error codes:

| Error | Code | Meaning |
|-------|------|---------|
| OPEN Message Error | 2/2 | Bad peer AS — wrong remote-as |
| OPEN Message Error | 2/4 | Unsupported optional parameter | 
| Hold Timer Expired | 4 | BGP hellos (keepalives) not received — check CPU, interface |
| Cease/Admin Reset | 6/4 | Neighbor was manually reset (`clear ip bgp`) |

---

## Step 6 — Enable BGP Debugging (Use with Caution)

⚠️ **WARNING:** BGP debug generates massive output on production routers. Only enable on a quiet router, for a short time, with terminal monitor active.

```bash
terminal monitor
debug ip bgp 203.0.113.1 events       ← State changes
debug ip bgp 203.0.113.1 updates      ← Route updates (very verbose)
```

Watch for:
- `%BGP-5-ADJCHANGE: neighbor 203.0.113.1 Up` → session came up
- `%BGP-3-NOTIFICATION: sent to neighbor 203.0.113.1` → we sent an error

Always disable debug after use:
```bash
undebug all
```

---

## Step 7 — Reset the BGP Session

If config is correct and physical connectivity is fine, try a soft reset first:

```bash
# Soft reset (no session drop, just refresh routes)
clear ip bgp 203.0.113.1 soft

# Hard reset (drops and re-establishes TCP session) — only if soft doesn't work
clear ip bgp 203.0.113.1
```

After reset, watch the state with:
```bash
watch 2 show bgp summary    ← Updates every 2 seconds
```

---

## Step 8 — Call ISP NOC

If all local checks pass and the session still doesn't come up, the issue is on the ISP side.

**Information to provide to ISP NOC:**
1. Your BGP AS number: 65001
2. Your WAN IP: 203.0.113.2
3. ISP peer IP: 203.0.113.1
4. BGP session state: (e.g., `Active`)
5. Timestamp when issue started
6. Any recent changes on your side
7. Output of `show bgp neighbors 203.0.113.1`

---

## Post-Resolution

Once BGP is `Established`, verify:
```bash
show bgp summary              ← Session established, prefix count > 0
show ip route bgp             ← Default route present
ping 8.8.8.8                  ← Internet reachable
show bgp neighbors 203.0.113.1 | include prefixes   ← Route counts
```

Document the root cause and resolution in the incident ticket.
