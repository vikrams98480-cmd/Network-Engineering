# Runbook DC-02 — Thermal Alert in Data Center

**Symptom:** Temperature sensor threshold exceeded on a server, switch, or environment monitor. May present as SNMP trap, Grafana alert, or physical amber LED on equipment.  
**Severity:** P1 if equipment is at risk of shutdown. P2 if approaching threshold.  
**Time to act:** Immediate — servers throttle CPU at ~85°C and emergency-shutdown at ~90°C. Some equipment does not warn before shutting down.

---

## Safety First

⚠️ Before investigating, confirm:
- You are not working in a live electrical panel or near energised bus bars
- You have a buddy if entering a hot aisle above 40°C (heat exhaustion risk)
- Wear ESD wrist strap if touching equipment

---

## Step 1 — Identify the Scope

**Is this one device or a zone?**

```bash
# Check SNMP thermal traps in monitoring system
# OR check server BMC directly:

# Dell iDRAC
racadm -r 10.10.40.50 -u root -p password getsensorinfo | grep -i temp

# HPE iLO
curl -k -u admin:password https://10.10.40.51/redfish/v1/Chassis/1/Thermal
```

Also check the physical environment monitor (APC NetBotz, Raritan, etc.) for room-level sensors.

**Scope:** single device vs. multiple devices in the same rack vs. entire aisle

---

## Step 2 — Single Device Overheating

### 2a — Check device airflow

**Front-to-rear airflow is standard** (cold aisle intake at front, hot exhaust at rear).

Physical checks:
- ✅ All blanking panels in place? Even one missing 1U gap can recirculate hot air into the intake
- ✅ Air filter clean? (servers have a replaceable dust filter behind the bezel)
- ✅ Front bezel removed or damaged? Bezels direct airflow — some servers need them
- ✅ Cable management not blocking rear exhaust vents?

### 2b — Check fan status

```bash
# Dell iDRAC (RACADM)
racadm -r 10.10.40.50 -u root -p password getsensorinfo | grep -i fan

# IPMI (works on most servers)
ipmitool -I lanplus -H 10.10.40.50 -U root -P password sdr type Fan
```

If a fan shows `0 RPM` or `absent` → hardware failure. Replace fan module immediately.
Most servers can run short-term on N-1 fans but will throttle CPU.

### 2c — Check CPU/memory utilisation

High CPU = high heat. A runaway process can push a server from 60°C to 85°C.

```bash
# From OS (if accessible)
top -bn1 | head -20
vmstat 1 5

# Check for runaway processes
ps aux --sort=-%cpu | head -10
```

If one process is consuming 100% CPU unexpectedly → investigate and kill if appropriate.

### 2d — Reseat components

If the server was recently worked on:
- Reseat DIMMs — a poorly seated DIMM generates excess heat and causes memory errors
- Reseat PCIe cards — same reason
- Ensure heatsink is properly mated to CPU (thermal paste contact)

---

## Step 3 — Multiple Devices in Same Rack Overheating

This indicates a **rack-level** airflow problem.

### 3a — Check blanking panels

Walk the hot aisle and look at the rear of the rack. Any gaps at the front translate to hot air recirculation.

**Add blanking panels immediately.** This is the most common cause of rack overheating and takes 2 minutes to fix.

### 3b — Check PDU and cable bulk

Excessive cable bulk near the front of the rack can obstruct server intake fans. Cable management arms (CMAs) that are fully loaded restrict airflow at the rear.

### 3c — Check CRAC/CRAH output for this rack row

Each CRAC (Computer Room Air Conditioner) or CRAH (Computer Room Air Handler) serves a zone. Check the unit serving this row:
- Supply air temperature should be 16–20°C at the perforated tiles
- If supply temp is correct but racks are hot → containment breach (hot and cold air mixing)
- If supply temp is elevated → CRAC unit problem (refrigerant, coil, compressor)

```bash
# Check APC InRow cooling unit via SNMP
snmpget -v2c -c public 10.10.40.200 .1.3.6.1.4.1.318.1.1.13.3.2.2.1.2.0
# OID above = APC supply air temperature
```

### 3d — Check raised floor tiles

If using raised floor cooling:
- Perforated tiles should be in front of racks (cold aisle), not in hot aisle
- Solid tiles in hot aisle prevent cold air from leaking under hot aisle
- Tiles near high-density racks should have higher open area (more airflow)

---

## Step 4 — Entire Room / Multiple Rows Overheating

This is a data center-wide HVAC failure.

### Immediate actions (first 5 minutes):

1. **Alert data center facilities team immediately** — this is their domain
2. **Check all CRAC/CRAH units** — are they running? Any fault lights?
3. **Open hot aisle containment doors** if temperature is rapidly rising — this mixes air but buys time by allowing circulation
4. **Identify equipment shutdown priority** — shut down non-critical servers before they thermal-shutdown uncontrolled (ungraceful shutdown = filesystem corruption)

### Controlled shutdown priority (lowest to highest criticality):

```
1. Dev/test servers          (shut first)
2. Non-critical app servers
3. Database replicas
4. Primary databases
5. Domain controllers / DNS  (shut last — needed for orderly shutdown of everything else)
```

```bash
# Graceful Linux shutdown
shutdown -h +2 "Data center thermal emergency — shutting down in 2 minutes"

# Graceful Windows shutdown
shutdown /s /t 120 /c "Data center thermal emergency"
```

### 4a — Check CRAC unit status

Walk the perimeter of the data center and check each CRAC unit:

| Indicator | Meaning |
|-----------|---------|
| Green LED | Normal operation |
| Amber LED | Warning (check display for error code) |
| Red LED | Fault — unit stopped cooling |
| Unit not running (no airflow) | Power failure to unit, or unit tripped |

Common CRAC faults:
- **High discharge pressure** → blocked condenser coils, check if condenser fans running (for DX units) or cooling water flow (for chilled water units)
- **Low suction pressure** → refrigerant leak — call HVAC tech, evacuate if strong chemical smell
- **High return air temperature** → containment breach or massive IT load increase
- **Water alarm** → condensate drain blocked or leak detected under floor

### 4b — Generator and UPS check

Power fluctuations cause CRAC compressors to cycle on/off, losing cooling temporarily.

```bash
# Check UPS status (APC via SNMP)
snmpwalk -v2c -c public 10.10.40.200 .1.3.6.1.4.1.318.1.1.1.4
```

---

## Step 5 — Post-Incident

After temperature returns to normal (≤27°C return air, ≤35°C inlet to equipment):

1. Confirm all equipment came back online cleanly
2. Check for filesystem errors on any servers that thermal-shutdown:
   ```bash
   dmesg | grep -i error
   journalctl -p err --since "1 hour ago"
   ```
3. Check for memory errors (thermal events can cause uncorrected ECC errors):
   ```bash
   ipmitool sel list | grep -i memory
   edac-util -s 1
   ```
4. Document the incident: time, peak temperature recorded, affected equipment, root cause, resolution
5. Order spare blanking panels if that was the cause (keep a stock of 1U and 2U panels)
6. Schedule CRAC preventive maintenance if unit was at fault
