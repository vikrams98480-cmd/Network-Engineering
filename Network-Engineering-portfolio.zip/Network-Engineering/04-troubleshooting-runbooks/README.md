# 04 · Troubleshooting Runbooks

## 🎯 Project Goal

A library of **systematic fault isolation runbooks** covering the most common enterprise network and data center failures. Each runbook follows the OSI model from bottom to top — the fastest path to root cause.

> **Why runbooks?** Senior engineers carry this knowledge in their heads. Runbooks transfer it to paper so junior engineers can resolve incidents at 2am without escalating, and so the senior engineer can review the fix in the morning and know exactly what was done.

---

## 📂 Runbook Index

| # | Runbook | Scenario |
|---|---------|----------|
| L1-01 | [Physical Link Down](layer1/L1-01-physical-link-down.md) | Port shows `down/down` |
| L1-02 | [Intermittent CRC Errors](layer1/L1-02-crc-errors.md) | High error count on interface |
| L2-01 | [VLAN Not Passing Traffic](layer2/L2-01-vlan-not-passing.md) | Users on VLAN X can't reach gateway |
| L2-02 | [STP Topology Change Loop](layer2/L2-02-stp-topology-change.md) | Network slows down, CPU spikes |
| L3-01 | [Route Not in Routing Table](layer3/L3-01-missing-route.md) | Ping fails, no route to host |
| L3-02 | [OSPF Neighbor Stuck in EXSTART](layer3/L3-02-ospf-exstart.md) | OSPF won't form adjacency |
| L3-03 | [BGP Session Down](layer3/L3-03-bgp-session-down.md) | Internet connectivity lost |
| DC-01 | [Server Not Detected in Rack](datacenter/DC-01-server-not-detected.md) | New server won't POST or network |
| DC-02 | [Thermal Alert in Data Center](datacenter/DC-02-thermal-alert.md) | Temperature threshold exceeded |
