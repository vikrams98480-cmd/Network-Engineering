#!/usr/bin/env python3
"""
compliance_checker.py
=====================
Check all network devices against a defined golden standard config
and report any drifted settings. Sends a Slack alert when drift is found.

WHY CONFIG COMPLIANCE MATTERS:
  Config drift happens when someone SSHes into a device and makes a
  "quick fix" that never gets documented or rolled back. Over time,
  your network becomes a snowflake — every device is slightly different
  from the standard. This causes:
    - Unpredictable failures (worked on device A, breaks on device B)
    - Security vulnerabilities (password policy not enforced everywhere)
    - Audit failures (PCI-DSS, SOC2 require consistent configs)

  This script runs nightly via cron and alerts on any deviation.

USAGE:
  python compliance_checker.py
  python compliance_checker.py --report-only    # No Slack alerts

HOW IT WORKS:
  1. Connect to every device in the Nornir inventory
  2. Pull the running config via NAPALM
  3. Compare against the golden standard rules in compliance_rules.yaml
  4. Generate a report showing which devices pass/fail which checks
  5. Send a Slack alert if any device fails

REQUIREMENTS:
  pip install nornir nornir-napalm nornir-utils napalm requests pyyaml
  export NET_USER=netadmin
  export NET_PASS=yourpassword
  export SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
"""

import os
import re
import sys
import json
import yaml
import requests
import argparse
from datetime import datetime
from pathlib import Path
from nornir import InitNornir
from nornir.core.task import Task, Result
from nornir_napalm.plugins.tasks import napalm_get
from nornir_utils.plugins.functions import print_result

# ---------------------------------------------------------------------------
# COMPLIANCE RULES
# Loaded from compliance_rules.yaml — a list of checks that must pass.
# ---------------------------------------------------------------------------
def load_rules(path: str = "compliance_rules.yaml") -> list:
    """Load compliance rules from YAML file."""
    with open(path) as f:
        return yaml.safe_load(f)["rules"]


# ---------------------------------------------------------------------------
# COMPLIANCE CHECK FUNCTION
# This runs on every device via Nornir's parallel task runner.
# ---------------------------------------------------------------------------
def check_compliance(task: Task, rules: list) -> Result:
    """
    Pull device config via NAPALM and check against compliance rules.

    NAPALM (Network Automation and Programmability Abstraction Layer with
    Multivendor support) provides a unified API across Cisco IOS, NX-OS,
    Arista EOS, Juniper JunOS — same Python code works on all platforms.

    Returns a dict: { rule_name: {"pass": bool, "evidence": str} }
    """
    # Step 1: Get the running config
    # WHY napalm_get instead of raw CLI: NAPALM normalizes the output
    # across vendors. "get_config" works the same on IOS and EOS.
    result = task.run(
        task=napalm_get,
        getters=["config", "interfaces"]
    )

    running_config = result.result["config"]["running"]
    interfaces = result.result["interfaces"]

    findings = {}

    for rule in rules:
        rule_name = rule["name"]
        check_type = rule["type"]

        # ---------------------------------------------------------------
        # CHECK TYPE: regex_must_exist
        # The pattern MUST be found in the config. Fails if absent.
        # Example: SSH version 2 must be configured.
        # ---------------------------------------------------------------
        if check_type == "regex_must_exist":
            pattern = rule["pattern"]
            match = re.search(pattern, running_config, re.MULTILINE)
            findings[rule_name] = {
                "pass": bool(match),
                "evidence": match.group(0).strip() if match else f"MISSING: pattern not found → {pattern}",
                "severity": rule.get("severity", "medium")
            }

        # ---------------------------------------------------------------
        # CHECK TYPE: regex_must_not_exist
        # The pattern must NOT be found. Fails if present.
        # Example: Telnet must NOT be enabled.
        # ---------------------------------------------------------------
        elif check_type == "regex_must_not_exist":
            pattern = rule["pattern"]
            match = re.search(pattern, running_config, re.MULTILINE)
            findings[rule_name] = {
                "pass": not bool(match),
                "evidence": f"VIOLATION: found → {match.group(0).strip()}" if match else "Not present ✓",
                "severity": rule.get("severity", "high")
            }

        # ---------------------------------------------------------------
        # CHECK TYPE: interface_check
        # Checks that every active interface has a specific config.
        # Example: All access ports must have bpduguard enabled.
        # ---------------------------------------------------------------
        elif check_type == "interface_check":
            attr = rule["attribute"]
            expected = rule["expected_value"]
            failing_interfaces = []

            for intf_name, intf_data in interfaces.items():
                if intf_data.get("is_up") and not intf_name.startswith("Loopback"):
                    actual = intf_data.get(attr)
                    if actual != expected:
                        failing_interfaces.append(f"{intf_name}: {attr}={actual}")

            findings[rule_name] = {
                "pass": len(failing_interfaces) == 0,
                "evidence": ", ".join(failing_interfaces) if failing_interfaces else "All interfaces compliant ✓",
                "severity": rule.get("severity", "medium")
            }

    return Result(host=task.host, result=findings)


# ---------------------------------------------------------------------------
# REPORT GENERATION
# ---------------------------------------------------------------------------
def generate_report(results: dict) -> tuple[str, bool]:
    """
    Build a human-readable compliance report.

    Returns:
        (report_text, has_failures) tuple
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"# Network Compliance Report",
        f"# Generated: {timestamp}",
        f"# {'=' * 60}",
        ""
    ]

    has_failures = False
    summary = {"total_devices": 0, "compliant": 0, "non_compliant": 0}

    for hostname, device_findings in results.items():
        summary["total_devices"] += 1
        device_pass = all(f["pass"] for f in device_findings.values())

        if device_pass:
            summary["compliant"] += 1
            status = "✅ PASS"
        else:
            summary["non_compliant"] += 1
            has_failures = True
            status = "❌ FAIL"

        lines.append(f"\n## {hostname}  {status}")
        lines.append(f"{'─' * 50}")

        for rule_name, finding in device_findings.items():
            icon = "✓" if finding["pass"] else "✗"
            sev = f"[{finding['severity'].upper()}]" if not finding["pass"] else ""
            lines.append(f"  {icon} {rule_name} {sev}")
            if not finding["pass"]:
                lines.append(f"      Evidence: {finding['evidence']}")

    lines.insert(3, f"# Summary: {summary['compliant']}/{summary['total_devices']} devices compliant")
    return "\n".join(lines), has_failures


# ---------------------------------------------------------------------------
# SLACK NOTIFICATION
# WHY: Email is slow and gets ignored. Slack alerts go to the #network-ops
#      channel where the on-call engineer sees them immediately.
# ---------------------------------------------------------------------------
def send_slack_alert(report: str, non_compliant_count: int):
    """Post a compliance failure alert to Slack."""
    webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
    if not webhook_url:
        print("WARNING: SLACK_WEBHOOK_URL not set — skipping Slack notification")
        return

    # Truncate report for Slack (max block size is 3000 chars)
    truncated = report[:2800] + "...(see full report in logs)" if len(report) > 2800 else report

    payload = {
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"🚨 Config Compliance Alert — {non_compliant_count} device(s) drifted"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"```{truncated}```"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*Action required:* Review and remediate config drift before next audit."
                }
            }
        ]
    }

    resp = requests.post(webhook_url, json=payload, timeout=10)
    if resp.status_code == 200:
        print("Slack alert sent ✓")
    else:
        print(f"Slack alert failed: {resp.status_code} {resp.text}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Network compliance checker")
    parser.add_argument("--report-only", action="store_true",
                        help="Generate report but do not send Slack alert")
    parser.add_argument("--rules", default="compliance_rules.yaml",
                        help="Path to compliance rules YAML")
    args = parser.parse_args()

    rules = load_rules(args.rules)

    # Initialize Nornir
    # WHY NORNIR: Nornir runs tasks in parallel across all devices using
    # a thread pool. Checking 50 devices takes the same time as checking 1.
    nr = InitNornir(config_file="nornir.yaml")

    print(f"Running compliance check on {len(nr.inventory.hosts)} devices...")

    # Run compliance check on all devices in parallel
    nr_results = nr.run(
        task=check_compliance,
        rules=rules
    )

    # Collect results into a simple dict
    all_findings = {}
    for hostname, result in nr_results.items():
        if not result.failed:
            all_findings[hostname] = result[1].result
        else:
            print(f"ERROR: Could not connect to {hostname}: {result[0].exception}")

    # Generate report
    report, has_failures = generate_report(all_findings)
    print(report)

    # Save report to file
    Path("logs").mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = f"logs/compliance_report_{ts}.txt"
    Path(report_path).write_text(report)
    print(f"\nFull report saved to: {report_path}")

    # Send Slack alert if failures found
    if has_failures and not args.report_only:
        non_compliant = sum(
            1 for findings in all_findings.values()
            if not all(f["pass"] for f in findings.values())
        )
        send_slack_alert(report, non_compliant)

    sys.exit(1 if has_failures else 0)


if __name__ == "__main__":
    main()
