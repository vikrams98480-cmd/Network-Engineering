# 03 · Network Automation

## 🎯 Project Goal

Automate repetitive, error-prone network tasks using **Python** (Netmiko, NAPALM, Nornir) and **Ansible**. Each sub-project solves a real operational problem.

| Sub-project | Problem Solved | Tool |
|-------------|---------------|------|
| [bgp-automation](./bgp-automation/) | Manual BGP policy pushes take hours and cause typos | Python + Netmiko + Jinja2 |
| [vlan-automation](./vlan-automation/) | Adding a VLAN requires logging into 20 switches one by one | Ansible |
| [compliance-checker](./compliance-checker/) | No automated way to know if device configs drift from the standard | Nornir + NAPALM |
| [telemetry](./telemetry/) | SNMP polling is slow and misses sub-minute events | gNMI + Telegraf + InfluxDB |

---

## 🔧 Environment Setup

### Python dependencies
```bash
pip install netmiko napalm nornir nornir-netmiko nornir-napalm jinja2 pyyaml paramiko
```

### Ansible
```bash
pip install ansible
ansible-galaxy collection install cisco.ios arista.eos
```

### Inventory structure
All projects share a common inventory defined in `inventory/hosts.yaml`.

```yaml
# inventory/hosts.yaml
all:
  children:
    core_switches:
      hosts:
        core-sw-1:
          hostname: 10.10.40.201
          platform: cisco_ios
        core-sw-2:
          hostname: 10.10.40.202
          platform: cisco_ios
    distribution_switches:
      hosts:
        dist-sw-1:
          hostname: 10.10.40.2
          platform: cisco_ios
        dist-sw-2:
          hostname: 10.10.40.3
          platform: cisco_ios
    access_switches:
      hosts:
        acc-sw-1:
          hostname: 10.10.40.11
          platform: cisco_ios
        acc-sw-2:
          hostname: 10.10.40.12
          platform: cisco_ios
```

Credentials are **never** stored in the repo. Use environment variables:
```bash
export NET_USER=netadmin
export NET_PASS=Ch@ng3M3!
export NET_SECRET=3n@bl3M3!
```
