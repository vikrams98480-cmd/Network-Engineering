#!/usr/bin/env python3
"""
bgp_policy_push.py
==================
Push BGP route-map and prefix-list configurations to multiple
Cisco IOS/IOS-XE routers using Netmiko + Jinja2 templates.

WHY THIS EXISTS:
  BGP policy changes (prefix filters, route-maps, communities) are
  high-risk changes. Manual SSH to each device introduces human error.
  This script:
    1. Renders configs from a Jinja2 template (consistent, no typos)
    2. Does a dry-run diff first (shows you what will change)
    3. Pushes and verifies the change
    4. Rolls back automatically if verification fails

USAGE:
  # Dry run (no changes made)
  python bgp_policy_push.py --dry-run

  # Push to all devices
  python bgp_policy_push.py

  # Push to specific device only
  python bgp_policy_push.py --device wan-edge-rtr

REQUIREMENTS:
  pip install netmiko jinja2 pyyaml
  export NET_USER=netadmin
  export NET_PASS=yourpassword
"""

import os
import sys
import argparse
import logging
import yaml
from datetime import datetime
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException

# ---------------------------------------------------------------------------
# LOGGING SETUP
# WHY: Always log what the script does. If something goes wrong at 2am,
#      the log file tells you exactly what happened and on which device.
# ---------------------------------------------------------------------------
log_dir = Path("logs")
log_dir.mkdir(exist_ok=True)
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = log_dir / f"bgp_push_{timestamp}.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LOAD DEVICE INVENTORY
# WHY: Inventory lives in a YAML file (not hardcoded) so you can add/remove
#      devices without touching the script.
# ---------------------------------------------------------------------------
def load_inventory(path: str = "inventory/hosts.yaml") -> list:
    """Load device list from YAML inventory file."""
    with open(path) as f:
        raw = yaml.safe_load(f)

    devices = []
    # Flatten the nested group structure into a simple list
    for group_name, group_data in raw["all"]["children"].items():
        for hostname, host_vars in group_data.get("hosts", {}).items():
            devices.append({
                "name": hostname,
                "hostname": host_vars["hostname"],
                "platform": host_vars.get("platform", "cisco_ios"),
            })
    return devices


# ---------------------------------------------------------------------------
# RENDER CONFIG FROM JINJA2 TEMPLATE
# WHY: Jinja2 templates produce identical, correct configs every time.
#      The alternative (manually typing the same block 20 times) will
#      eventually produce a typo that causes a routing incident.
# ---------------------------------------------------------------------------
def render_bgp_config(device_name: str, policy_vars: dict) -> str:
    """
    Render BGP config for a device from the Jinja2 template.

    Args:
        device_name: hostname (used to look up device-specific vars)
        policy_vars: dict loaded from bgp_policy.yaml

    Returns:
        Rendered config string ready to be pushed to the device
    """
    env = Environment(loader=FileSystemLoader("templates"))
    template = env.get_template("bgp_policy.j2")
    return template.render(device=device_name, **policy_vars)


# ---------------------------------------------------------------------------
# CONNECT AND PUSH CONFIG
# WHY: Netmiko handles SSH connection, privilege escalation, and config mode
#      for dozens of different NOS platforms (IOS, NX-OS, EOS, JunOS etc.)
#      so we don't have to write the SSH plumbing ourselves.
# ---------------------------------------------------------------------------
def push_config(device: dict, config: str, dry_run: bool = False) -> bool:
    """
    Connect to a device and push config. Returns True on success.

    In dry_run mode, shows a diff of what would change without applying.
    """
    conn_params = {
        "device_type": device["platform"],
        "host": device["hostname"],
        "username": os.environ["NET_USER"],
        "password": os.environ["NET_PASS"],
        "secret": os.environ.get("NET_SECRET", ""),
        "timeout": 30,
        "session_log": log_dir / f"{device['name']}_session.log",
    }

    try:
        log.info(f"Connecting to {device['name']} ({device['hostname']})")
        with ConnectHandler(**conn_params) as ssh:
            ssh.enable()  # Enter privileged exec mode

            if dry_run:
                # ---------------------------------------------------------------------------
                # DRY RUN: Use NAPALM-style diff or simply show what we would push
                # WHY: Always give the engineer a chance to review changes before they apply.
                #      'configure replace' on IOS shows a diff; on NX-OS use 'diff rollback-patch'
                # ---------------------------------------------------------------------------
                log.info(f"[DRY RUN] Would push the following config to {device['name']}:")
                log.info("-" * 60)
                for line in config.splitlines():
                    log.info(f"  + {line}")
                log.info("-" * 60)
                return True

            # ---------------------------------------------------------------------------
            # BACKUP: Capture running config BEFORE making changes
            # WHY: If the push causes issues, you need the pre-change state to roll back.
            # ---------------------------------------------------------------------------
            backup_path = log_dir / f"{device['name']}_backup_{timestamp}.txt"
            log.info(f"Backing up running config to {backup_path}")
            running_config = ssh.send_command("show running-config")
            backup_path.write_text(running_config)

            # ---------------------------------------------------------------------------
            # PUSH CONFIG
            # send_config_set() enters config mode, sends each line, then exits.
            # ---------------------------------------------------------------------------
            log.info(f"Pushing BGP policy config to {device['name']}")
            output = ssh.send_config_set(config.splitlines())
            log.info(f"Output:\n{output}")

            # ---------------------------------------------------------------------------
            # VERIFY: Check BGP neighbors are still Established after the change
            # WHY: A misconfigured prefix list can cause BGP to drop the session.
            #      Verify immediately and roll back if anything is wrong.
            # ---------------------------------------------------------------------------
            log.info(f"Verifying BGP neighbors on {device['name']}")
            bgp_output = ssh.send_command("show bgp summary", use_textfsm=True)

            if isinstance(bgp_output, list):
                for neighbor in bgp_output:
                    state = str(neighbor.get("state_pfxrcd", ""))
                    if not state.isdigit():
                        # Non-numeric state means BGP is not Established (e.g. "Idle", "Active")
                        log.error(
                            f"BGP neighbor {neighbor.get('bgp_neigh')} is in state '{state}' "
                            f"on {device['name']} — rolling back!"
                        )
                        rollback(ssh, backup_path)
                        return False
                log.info(f"All BGP neighbors Established on {device['name']} ✓")
            else:
                log.warning(f"Could not parse BGP summary on {device['name']} — review manually")

            # Save the running config after change
            ssh.send_command("write memory")
            log.info(f"Config saved on {device['name']}")
            return True

    except NetmikoAuthenticationException:
        log.error(f"Authentication failed for {device['name']} — check credentials")
        return False
    except NetmikoTimeoutException:
        log.error(f"Connection timed out for {device['name']} — check reachability")
        return False
    except Exception as e:
        log.error(f"Unexpected error on {device['name']}: {e}")
        return False


def rollback(ssh, backup_path: Path):
    """
    Roll back to the pre-change config by re-pushing the backup.

    WHY: Automated rollback is critical for safe network automation.
         Without it, a bad change stays in place until someone notices.
    """
    log.warning(f"Rolling back to backup config: {backup_path}")
    backup_config = backup_path.read_text()
    # Strip non-config lines (comments, timestamps) before pushing
    config_lines = [
        line for line in backup_config.splitlines()
        if line and not line.startswith("!")
    ]
    ssh.send_config_set(config_lines)
    log.info("Rollback complete")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Push BGP policy configs")
    parser.add_argument("--dry-run", action="store_true", help="Show diff only, no changes")
    parser.add_argument("--device", help="Target a specific device by name")
    parser.add_argument("--policy", default="vars/bgp_policy.yaml", help="Policy vars file")
    args = parser.parse_args()

    # Load the BGP policy variables (prefix lists, communities, AS paths)
    with open(args.policy) as f:
        policy_vars = yaml.safe_load(f)

    # Load inventory
    devices = load_inventory()
    if args.device:
        devices = [d for d in devices if d["name"] == args.device]
        if not devices:
            log.error(f"Device '{args.device}' not found in inventory")
            sys.exit(1)

    results = {"success": [], "failed": []}

    for device in devices:
        # Only push to routers, not switches (BGP runs on routers/L3 switches)
        if "sw" in device["name"] and "dist" not in device["name"]:
            log.info(f"Skipping {device['name']} (access switch, no BGP)")
            continue

        config = render_bgp_config(device["name"], policy_vars)

        if push_config(device, config, dry_run=args.dry_run):
            results["success"].append(device["name"])
        else:
            results["failed"].append(device["name"])

    # Summary
    log.info("=" * 60)
    log.info(f"COMPLETE — Success: {len(results['success'])}  Failed: {len(results['failed'])}")
    if results["failed"]:
        log.error(f"Failed devices: {', '.join(results['failed'])}")
        sys.exit(1)


if __name__ == "__main__":
    main()
