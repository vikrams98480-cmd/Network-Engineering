# 01 · Enterprise Network Design

## 🎯 Project Goal

Design and configure a **three-tier enterprise campus network** that supports 500+ users across three access layers, two distribution switches, and a collapsed core. The design also includes a WAN edge connecting to a remote branch via BGP.

This project proves you can:
- Plan IP addressing and VLAN segmentation for an enterprise
- Configure Layer 2 (STP, VLANs, trunking) and Layer 3 (OSPF, BGP, HSRP)
- Apply security hardening and ACLs
- Validate reachability and redundancy

---

## 🏗️ Network Topology

```
                          [ INTERNET / ISP ]
                                 |
                         [ WAN-EDGE-RTR ]   ← BGP to ISP
                                 |
              ┌──────────────────┴──────────────────┐
          [ CORE-SW-1 ]                       [ CORE-SW-2 ]
         (Layer 3, OSPF)                     (Layer 3, OSPF)
              │                                     │
      ┌───────┴──────┐                    ┌──────────┴───────┐
  [DIST-SW-1]    [DIST-SW-2]          [DIST-SW-3]        [DIST-SW-4]
  (HSRP Active)  (HSRP Standby)       (HSRP Active)      (HSRP Standby)
      │                │                    │                  │
  [ACC-SW-1]      [ACC-SW-2]           [ACC-SW-3]         [ACC-SW-4]
  Floor 1         Floor 2              Floor 3             Server Farm
```

**VLANs:**

| VLAN ID | Name         | Subnet            | Purpose                  |
|---------|--------------|-------------------|--------------------------|
| 10      | USERS        | 10.10.10.0/24     | End-user workstations    |
| 20      | VOIP         | 10.10.20.0/24     | IP phones                |
| 30      | SERVERS      | 10.10.30.0/24     | Internal servers         |
| 40      | MANAGEMENT   | 10.10.40.0/24     | Network device OOB mgmt  |
| 99      | NATIVE       | N/A               | Native/untagged (unused) |

---

## 📋 Step-by-Step Explanation

### Step 1 — IP Addressing Plan

**Why:** Before touching a single device, you must define your IP address scheme. This prevents overlap, simplifies troubleshooting, and makes the network scalable.

The plan follows a structured `/24`-per-VLAN approach. Management IPs are in VLAN 40 so you always have out-of-band access even if user VLANs fail.

```
WAN Link:       203.0.113.0/30   (public, assigned by ISP)
Loopbacks:      10.0.0.X/32      (one per router/L3 switch, used by OSPF)
VLANs:          10.10.X.0/24     (one subnet per VLAN as above)
```

---

### Step 2 — VLAN and Trunking (Access Switches)

**Why:** VLANs segment broadcast domains. Trunk links carry multiple VLANs between switches using 802.1Q tags.

Every access switch gets all VLANs defined, but only the correct one is assigned to access ports. Uplinks to distribution are configured as trunks allowing only the VLANs that floor needs (pruning reduces unnecessary BUM traffic).

See: [`configs/ACC-SW-1.cfg`](configs/ACC-SW-1.cfg)

---

### Step 3 — Spanning Tree (RSTP + Root Guard)

**Why:** Without STP, Layer 2 loops cause broadcast storms that instantly kill a network. RSTP (802.1w) converges in under 1 second vs 30–50 seconds for legacy STP.

- DIST-SW-1 is the **STP root for VLANs 10, 20** (primary) and DIST-SW-2 is secondary.
- DIST-SW-2 is the **STP root for VLANs 30, 40** (primary) — this load-balances traffic.
- `spanning-tree guard root` on all access ports prevents a rogue switch from becoming root.

See: [`configs/DIST-SW-1.cfg`](configs/DIST-SW-1.cfg)

---

### Step 4 — HSRP (First Hop Redundancy)

**Why:** Workstations need a single default gateway IP. HSRP (Hot Standby Router Protocol) creates a virtual IP shared between two distribution switches. If the active one fails, the standby takes over in ~3 seconds, invisible to users.

```
VLAN 10 gateway: 10.10.10.1  (virtual)
  DIST-SW-1: 10.10.10.2 — priority 110 (Active)
  DIST-SW-2: 10.10.10.3 — priority 100 (Standby)
```

HSRP groups are aligned with STP root — the same switch is both STP root and HSRP active for the same VLANs to avoid suboptimal forwarding.

See: [`configs/DIST-SW-1.cfg`](configs/DIST-SW-1.cfg)

---

### Step 5 — OSPF (Internal Routing)

**Why:** OSPF is the industry-standard IGP for enterprise networks. It discovers topology automatically, calculates shortest paths, and reconverges quickly after a failure.

All Layer 3 switches and the WAN-edge router run OSPF Area 0 (backbone). Loopback interfaces are advertised so they can be used as stable router-IDs and BGP peering addresses.

```
router ospf 1
 router-id 10.0.0.1
 network 10.0.0.0 0.255.255.255 area 0
 passive-interface default
 no passive-interface GigabitEthernet1/0/1   ← uplink to core
```

`passive-interface default` is a security best practice — OSPF hellos are only sent on explicitly enabled interfaces.

See: [`configs/WAN-EDGE-RTR.cfg`](configs/WAN-EDGE-RTR.cfg)

---

### Step 6 — BGP (WAN Edge to ISP)

**Why:** BGP is the protocol of the internet. Enterprises use eBGP on the WAN edge to exchange routes with their ISP and for multi-homing.

```
router bgp 65001
 neighbor 203.0.113.1 remote-as 65000    ← ISP AS
 network 203.0.113.0 mask 255.255.255.252
 default-information originate
```

A default route is redistributed into OSPF so all internal devices can reach the internet via the WAN edge.

See: [`configs/WAN-EDGE-RTR.cfg`](configs/WAN-EDGE-RTR.cfg)

---

### Step 7 — Access Control Lists (Security)

**Why:** ACLs are the first layer of traffic policy. They prevent VLAN 10 users from directly accessing the VLAN 40 management network, and block unwanted inter-VLAN traffic.

```
ip access-list extended BLOCK_USER_TO_MGMT
 deny   ip 10.10.10.0 0.0.0.255 10.10.40.0 0.0.0.255
 permit ip any any
```

Applied inbound on the VLAN 10 SVI of the distribution switch.

See: [`configs/DIST-SW-1.cfg`](configs/DIST-SW-1.cfg)

---

### Step 8 — Validation

**Why:** Never assume a config is working. Verify every protocol and path before handing over to operations.

```bash
# Verify VLANs
show vlan brief

# Verify trunks
show interfaces trunk

# Verify STP
show spanning-tree vlan 10

# Verify HSRP
show standby brief

# Verify OSPF neighbors
show ip ospf neighbor

# Verify BGP
show bgp summary

# End-to-end ping
ping 10.10.10.100 source 10.10.30.10 repeat 100
```

See: [`docs/validation-checklist.md`](docs/validation-checklist.md)
