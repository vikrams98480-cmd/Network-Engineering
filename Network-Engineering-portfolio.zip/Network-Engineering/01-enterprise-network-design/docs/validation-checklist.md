# Validation Checklist — Enterprise Network Design

Use this checklist after deploying every device. Tick each item before signing off on the change.

---

## Layer 2 Validation

### VLANs
```
show vlan brief
```
✅ All expected VLANs (10, 20, 30, 40, 99) appear with status `active`  
✅ No unexpected VLANs present  
✅ VLAN names match the naming convention  

### Trunks
```
show interfaces trunk
```
✅ Uplink ports appear in the trunk table  
✅ Allowed VLAN list matches the design (10,20,40,99 on floor uplinks)  
✅ Native VLAN is 99 on all trunks (not 1)  
✅ VLANs are in the `VLANs in spanning tree forwarding state` column  

### Spanning Tree
```
show spanning-tree vlan 10
show spanning-tree vlan 20
show spanning-tree vlan 30
show spanning-tree vlan 40
```
✅ DIST-SW-1 is Root Bridge for VLANs 10, 20  
✅ DIST-SW-2 is Root Bridge for VLANs 30, 40  
✅ All access ports show `P2p Edge` (portfast enabled)  
✅ No unexpected topology changes (check `show spanning-tree detail`)  

---

## Layer 3 Validation

### SVIs and IP addresses
```
show ip interface brief | include Vlan
```
✅ All SVIs show `up/up`  
✅ IP addresses match the design table  

### HSRP
```
show standby brief
```
✅ DIST-SW-1 shows `Active` for VLANs 10, 20  
✅ DIST-SW-2 shows `Active` for VLANs 30, 40  
✅ Virtual IP matches the gateway IP in the design  
✅ Authentication is negotiated (look for `auth` in `show standby`)  

### OSPF
```
show ip ospf neighbor
show ip route ospf
```
✅ All expected OSPF neighbors are in `FULL` state  
✅ OSPF routes for all remote subnets appear in the routing table  
✅ Default route `O*E2 0.0.0.0/0` is present on all distribution switches  

### BGP (WAN edge only)
```
show bgp summary
show bgp neighbors 203.0.113.1
show ip route bgp
```
✅ BGP neighbor is in `Established` state (state column shows a number = prefix count)  
✅ Default route is received from ISP (`0.0.0.0/0` in `show ip route bgp`)  
✅ Enterprise prefix is advertised to ISP  

---

## End-to-End Connectivity Tests

Run from a device in each VLAN to confirm inter-VLAN routing and internet access:

```bash
# From VLAN 10 (user workstation) — ping VLAN 30 server
ping 10.10.30.10 source vlan 10 repeat 100

# From VLAN 10 — ping internet (should be NAT'd)
ping 8.8.8.8 source 10.10.10.5

# From management — SSH into each switch
ssh netadmin@10.10.40.11   # ACC-SW-1
ssh netadmin@10.10.40.2    # DIST-SW-1

# Traceroute to verify path
traceroute 8.8.8.8 source 10.10.10.5
```

✅ All pings succeed with <5ms latency  
✅ Traceroute shows expected hop via DIST-SW-1 → WAN-EDGE-RTR → ISP  
✅ SSH accessible from management VLAN only  
✅ SSH from VLAN 10 is blocked (ACL working)  

---

## Redundancy Failover Tests

### HSRP Failover
1. Note active HSRP switch with `show standby brief` on DIST-SW-1  
2. Shut the active SVI: `interface Vlan10` → `shutdown`  
3. Verify DIST-SW-2 becomes active within 3 seconds  
4. Ping from a user device — should recover with <5 packet loss  
5. Re-enable the SVI and confirm DIST-SW-1 preempts back (with delay)  

✅ Failover completes in ≤3 seconds  
✅ Preemption works after recovery  

### Uplink Failover
1. Disconnect/shut one trunk uplink from ACC-SW-1 to DIST-SW-1  
2. Verify traffic shifts to the remaining uplink (STP convergence)  
3. Re-enable the link and confirm it comes back without issues  

✅ STP reconverges in ≤1 second (RSTP)  
✅ No duplicate packets or loops observed  
